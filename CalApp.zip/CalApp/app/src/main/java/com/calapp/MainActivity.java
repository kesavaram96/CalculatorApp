package com.calapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView tvResult;
    private String currentInput = "";
    private String operator = "";
    private double firstValue = Double.NaN;
    private double secondValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResult = findViewById(R.id.tvResult);

        setNumericOnClickListener();
        setOperatorOnClickListener();
    }

    private void setNumericOnClickListener() {
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button button = (Button) v;
                currentInput += button.getText().toString();
                tvResult.setText(currentInput);
            }
        };

        findViewById(R.id.btnZero).setOnClickListener(listener);
        findViewById(R.id.btnOne).setOnClickListener(listener);
        findViewById(R.id.btnTwo).setOnClickListener(listener);
        findViewById(R.id.btnThree).setOnClickListener(listener);
        findViewById(R.id.btnFour).setOnClickListener(listener);
        findViewById(R.id.btnFive).setOnClickListener(listener);
        findViewById(R.id.btnSix).setOnClickListener(listener);
        findViewById(R.id.btnSeven).setOnClickListener(listener);
        findViewById(R.id.btnEight).setOnClickListener(listener);
        findViewById(R.id.btnNine).setOnClickListener(listener);
        findViewById(R.id.btnDot).setOnClickListener(listener);
    }

    private void setOperatorOnClickListener() {
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button button = (Button) v;

                if (!Double.isNaN(firstValue)) {
                    secondValue = Double.parseDouble(currentInput);
                    performCalculation();
                    currentInput = "";
                } else {
                    firstValue = Double.parseDouble(currentInput);
                    currentInput = "";
                }

                operator = button.getText().toString();
                tvResult.setText(String.format("%s %s", firstValue, operator));
            }
        };

        findViewById(R.id.btnAdd).setOnClickListener(listener);
        findViewById(R.id.btnSubtract).setOnClickListener(listener);
        findViewById(R.id.btnMultiply).setOnClickListener(listener);
        findViewById(R.id.btnDivide).setOnClickListener(listener);

        findViewById(R.id.btnEqual).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Double.isNaN(firstValue)) {
                    secondValue = Double.parseDouble(currentInput);
                    performCalculation();
                    operator = "";
                    currentInput = String.valueOf(firstValue);
                    tvResult.setText(currentInput);
                    firstValue = Double.NaN;
                }
            }
        });

        findViewById(R.id.btnClear).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetCalculator();
            }
        });
    }

    private void performCalculation() {
        switch (operator) {
            case "+":
                firstValue = firstValue + secondValue;
                break;
            case "-":
                firstValue = firstValue - secondValue;
                break;
            case "×":
                firstValue = firstValue * secondValue;
                break;
            case "÷":
                if (secondValue != 0) {
                    firstValue = firstValue / secondValue;
                } else {
                    tvResult.setText("Error");
                    resetCalculator();
                    return;
                }
                break;
        }

        tvResult.setText(String.format("%s %s %s = %s",
                firstValue, operator, secondValue, firstValue));
    }

    private void resetCalculator() {
        tvResult.setText("0");
        currentInput = "";
        operator = "";
        firstValue = Double.NaN;
        secondValue = Double.NaN;
    }
}
